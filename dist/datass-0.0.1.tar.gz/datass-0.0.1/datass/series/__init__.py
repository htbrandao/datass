"""
datass submodule for handling pandas.Series objects
"""

__name__ = 'datass.series'
