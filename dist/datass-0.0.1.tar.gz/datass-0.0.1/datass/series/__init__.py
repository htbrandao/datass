"""
datass submodule for handling pandas.Series objects
"""
