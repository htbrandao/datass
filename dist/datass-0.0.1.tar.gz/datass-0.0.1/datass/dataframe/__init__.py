"""
datass submodule for handling pandas.DataFrame objects
"""

__name__ = 'datass.dataframe'
