"""
datass submodule for handling pandas.DataFrame objects
"""
