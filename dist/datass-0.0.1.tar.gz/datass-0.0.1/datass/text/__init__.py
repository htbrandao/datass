"""
datass submodule for handling str and list[str] and objects
"""
