"""
datass submodule for handling str and list[str] and objects
"""

__name__ = 'datass.text'
